import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [address, setAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [message, setMessage] = useState('');
  const [walletName, setWalletName] = useState('');
  const [newAddress, setNewAddress] = useState('');
  const [userWalletName, setUserWalletName] = useState('');


 const buyLitecoin = async (e) => {
  e.preventDefault();
  try {
    const response = await axios.post('http://localhost:3001/api/sendltcaddress', { address, amount });
    if (response.data.success) {
      setMessage(`Transaction successful! TXID: ${response.data.txid}`);
    } else {
      setMessage('Transaction failed.');
    }
  } catch (error) {
    setMessage(`Error: ${error.message}`);
  }
};

const generateWallet = async () => {
    try {
      const response = await axios.post('http://localhost:3001/api/generatewallet', { walletName: userWalletName });
      if (response.data.success) {
        setWalletName(response.data.walletCommand);
        setMessage('Wallet created successfully.  Wallet Name: ' + response.data.walletCommand );
      } else {
        setMessage('Failed to create wallet.');
      }
    } catch (error) {
      setMessage(`Error: ${error.message}`);
    }
  };
  
  const loadWallet = async () => {
    try {
      const response = await axios.post('http://localhost:3001/api/loadwallet', { walletName: userWalletName });
      if (response.data.success) {
        setMessage('Wallet loaded successfully.');
      } else {
        setMessage('Failed to load wallet.');
      }
    } catch (error) {
      setMessage(`Error: ${error.message}`);
    }
  };


  const getNewAddress = async () => {
    try {
      const response = await axios.post('http://localhost:3001/api/getnewaddress', { walletName: userWalletName });
      if (response.data.success) {
        setNewAddress(response.data.newAddress);
        setMessage('New address generated successfully.  Address Name: ' + response.data.newAddress);
      } else {
        setMessage('Failed to generate new address.');
      }
    } catch (error) {
      setMessage(`Error: ${error.message}`);
    }
  };


	return (
		<div className="App">
			<h1>Mock Litecoin Exchange</h1>
			<form onSubmit={buyLitecoin}>
				<div>
					<label htmlFor="address">Address:</label>
					<input
						type="text"
						id="address"
						value={address}
						onChange={(e) => setAddress(e.target.value)}
						required
					/>
					</div>
					<div>
						<label htmlFor="amount">Amount (LTC):</label>
					<input
					type="number"
					id="amount"
					value={amount}
					onChange={(e) => setAmount(e.target.value)}
					step="0.00000001"
					min="0.00000001"
					required
					/>
				</div>
				<button type="submit">Buy Litecoin</button>
			</form>
			<div>
				
					<div>
					  <label htmlFor="wallet-name">Wallet Name: </label>
					  <input
						id="wallet-name"
						type="text"
						value={userWalletName}
						onChange={(e) => setUserWalletName(e.target.value)}
					  />
					  <button onClick={generateWallet}>Generate Wallet</button>
					  <button onClick={loadWallet}>Load Wallet</button>

					</div>
					{walletName && <p>Generated Wallet: {walletName}</p>}

				  <button onClick={getNewAddress}>Generate New Address</button>
				  {newAddress && <p>Generated Address: {newAddress}</p>}
			</div>
			{message && <p>{message}</p>}
		</div>
	);
}

export default App;